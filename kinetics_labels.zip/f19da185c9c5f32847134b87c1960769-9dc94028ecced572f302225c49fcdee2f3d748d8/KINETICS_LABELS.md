# Kinetics Numeric/String labels

These are mapping files that go between class IDs to class names. These are generated from the training CSV files from each dataset by collecting the unique classes, sorting them, and then numbering them from 0 upwards.